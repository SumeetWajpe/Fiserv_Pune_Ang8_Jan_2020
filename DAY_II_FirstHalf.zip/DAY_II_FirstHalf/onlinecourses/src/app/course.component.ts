import { Component, Input } from '@angular/core';
import { CourseModel } from './course.model';

@Component({
    selector: 'course',
    templateUrl:'./course.component.html'

})
export class CourseComponent {
    @Input() coursedetails: CourseModel = new CourseModel();

}