//var str = "Hello Typescript !"; // Type Inference
var str:string; // type annotation
str = "Hello Typescript !"
//str = 100;
console.log(str);

var n:number;
var o:object;
var b:boolean;
var z:any;
z = 10;
z = "Hello";
z = [10,20,30];
z = {name:'Fiserv',location:'Pune'};

if(true){
    let blockScopedVar:number = 10000;
    // 100 lines of code 
    // let blockScopedVar; /// Error as variable already declared
    if(true){
        blockScopedVar = 20000; // accesible in nested block!
        console.log(blockScopedVar)
    }
}
const PI:number= 3.14;
// PI = 3.14567; // 
//console.log(blockScopedVar); // Error as variable is block scoped

// Spread Operator with Arrays
var cars:string[] = ["BMW","AUDI","FERRARI"];
var moreCars:Array<string> = new Array<string>("TATA","MARUTI","MAHINDRA");
var allCars = [...cars,...moreCars];
console.log(allCars);

// Spread Operator with Objects
var person = {name:'Virat',city:'Delhi'};
var player = {...person,runs:50000};
console.log(player.name);

// Functions

function Add(x:number,y:number):number|string{
    if(x<0){
        return 'X should be greater than 0 !';
    }
    return x + y;
}

var result:number|string = Add(10,20);

// Optional Parameters

// function PrintBooks(author?:string,title?:string){
//     console.log(author,title);
// }

// PrintBooks("Dummy","Dummy");

// Default parameters

// function PrintBooks(author:string="Unknown",title:string="Unknown"){
//     console.log(author,title);
// }

// PrintBooks();
//PrintBooks("Sachin Tendulkar","Playing It My Way");
//PrintBooks(undefined,"Dummy");

// Rest Parameters

// function PrintBooks(author:string,...titles:string[]){
//     console.log(author,titles);
// }

// PrintBooks("Dr. Apj Abdul Kalam","Wings of Fire","India 2020")
// PrintBooks("Ranjit Desai","Mrutyunjay","Radhey","Shriman Yogi","Swami");

// Arrow Functions

// function Square(x){
//     return x * x;
// }

// Function as an expression
// var Square = function(x){
//     return x *x;
// }

// Arrow Function

// var Square = (x) => {
//     return x * x;
// } 
// OR
var Square = x => x * x;

// allCars.forEach(function(car){
//     console.log(car);
// });
// OR
//llCars.forEach((car:string)=>console.log(car));

function Emp(){
    this.salary = 50000;         
    setTimeout(()=>{
        console.log(this.salary);
    },3000)
}
var e = new Emp();

// Destructuring with Arrays
let firstCar,secondCar,thirdCar;

 [firstCar,,secondCar,thirdCar="Default Car"] = ["BMW","AUDI","FERRARI"];
console.log(secondCar);

// Destructuring with Objects

var title,author;

var bookDetails  = {title:'Mrutyunjay',author:'Ranjit Desai'};
({title,author} = bookDetails);


interface IEmp{
    name:string;
    salary?:number;
    getDetails?():void;
}

var emp:IEmp = {name:'Aniket'};


class Car{
    name:string;
    speed:number;
    constructor(name:string="i20",speed:number=100){
        this.name = name;
        this.speed = speed;
    }
    accelerate():string{
            //console.log('The car ' + this.name + " is running at " + this.speed + " kmph !")
            return (`The car ${this.name} is running at ${this.speed} kmph !`);
    }
}

// var carObj:Car = new Car();
// console.log(carObj.name);
// carObj.accelerate();

// var multiLineStr = `First Line !
// Second Line !
// Last LIne !`;

// console.log(multiLineStr)


class JamesBondCar extends Car{
    canFly:boolean;
    useNitroPower:boolean;
    constructor(n:string,s:number,fly:boolean,nitro:boolean){
        super(n,s);
        this.canFly = fly;
        this.useNitroPower = nitro;
    }
    accelerate(){
        return super.accelerate() + " Can Fly ? :" + this.canFly;
    }
}

var jbc:JamesBondCar = new JamesBondCar("Aston Martin",500,true,true);
console.log(jbc.accelerate());


class Employee implements IEmp{
        name:string;
        salary:number;
        getDetails(){
            console.log(this.name ,this.salary)
        }
}

// Enhanced Class


class EnhancedCar{
    constructor(public name:string="i20",public speed:number=200){
        
    }
}

var enCar = new EnhancedCar();