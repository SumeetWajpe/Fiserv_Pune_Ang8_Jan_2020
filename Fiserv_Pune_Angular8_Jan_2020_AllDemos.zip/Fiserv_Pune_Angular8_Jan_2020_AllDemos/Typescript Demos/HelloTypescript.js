var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
var __spreadArrays = (this && this.__spreadArrays) || function () {
    for (var s = 0, i = 0, il = arguments.length; i < il; i++) s += arguments[i].length;
    for (var r = Array(s), k = 0, i = 0; i < il; i++)
        for (var a = arguments[i], j = 0, jl = a.length; j < jl; j++, k++)
            r[k] = a[j];
    return r;
};
var _a, _b;
//var str = "Hello Typescript !"; // Type Inference
var str; // type annotation
str = "Hello Typescript !";
//str = 100;
console.log(str);
var n;
var o;
var b;
var z;
z = 10;
z = "Hello";
z = [10, 20, 30];
z = { name: 'Fiserv', location: 'Pune' };
if (true) {
    var blockScopedVar = 10000;
    // 100 lines of code 
    // let blockScopedVar; /// Error as variable already declared
    if (true) {
        blockScopedVar = 20000; // accesible in nested block!
        console.log(blockScopedVar);
    }
}
var PI = 3.14;
// PI = 3.14567; // 
//console.log(blockScopedVar); // Error as variable is block scoped
// Spread Operator with Arrays
var cars = ["BMW", "AUDI", "FERRARI"];
var moreCars = new Array("TATA", "MARUTI", "MAHINDRA");
var allCars = __spreadArrays(cars, moreCars);
console.log(allCars);
// Spread Operator with Objects
var person = { name: 'Virat', city: 'Delhi' };
var player = __assign(__assign({}, person), { runs: 50000 });
console.log(player.name);
// Functions
function Add(x, y) {
    if (x < 0) {
        return 'X should be greater than 0 !';
    }
    return x + y;
}
var result = Add(10, 20);
// Optional Parameters
// function PrintBooks(author?:string,title?:string){
//     console.log(author,title);
// }
// PrintBooks("Dummy","Dummy");
// Default parameters
// function PrintBooks(author:string="Unknown",title:string="Unknown"){
//     console.log(author,title);
// }
// PrintBooks();
//PrintBooks("Sachin Tendulkar","Playing It My Way");
//PrintBooks(undefined,"Dummy");
// Rest Parameters
// function PrintBooks(author:string,...titles:string[]){
//     console.log(author,titles);
// }
// PrintBooks("Dr. Apj Abdul Kalam","Wings of Fire","India 2020")
// PrintBooks("Ranjit Desai","Mrutyunjay","Radhey","Shriman Yogi","Swami");
// Arrow Functions
// function Square(x){
//     return x * x;
// }
// Function as an expression
// var Square = function(x){
//     return x *x;
// }
// Arrow Function
// var Square = (x) => {
//     return x * x;
// } 
// OR
var Square = function (x) { return x * x; };
// allCars.forEach(function(car){
//     console.log(car);
// });
// OR
//llCars.forEach((car:string)=>console.log(car));
function Emp() {
    var _this = this;
    this.salary = 50000;
    setTimeout(function () {
        console.log(_this.salary);
    }, 3000);
}
var e = new Emp();
// Destructuring with Arrays
var firstCar, secondCar, thirdCar;
_a = ["BMW", "AUDI", "FERRARI"], firstCar = _a[0], secondCar = _a[2], _b = _a[3], thirdCar = _b === void 0 ? "Default Car" : _b;
console.log(secondCar);
// Destructuring with Objects
var title, author;
var bookDetails = { title: 'Mrutyunjay', author: 'Ranjit Desai' };
(title = bookDetails.title, author = bookDetails.author);
var emp = { name: 'Aniket' };
var Car = /** @class */ (function () {
    function Car(name, speed) {
        if (name === void 0) { name = "i20"; }
        if (speed === void 0) { speed = 100; }
        this.name = name;
        this.speed = speed;
    }
    Car.prototype.accelerate = function () {
        //console.log('The car ' + this.name + " is running at " + this.speed + " kmph !")
        return ("The car " + this.name + " is running at " + this.speed + " kmph !");
    };
    return Car;
}());
// var carObj:Car = new Car();
// console.log(carObj.name);
// carObj.accelerate();
// var multiLineStr = `First Line !
// Second Line !
// Last LIne !`;
// console.log(multiLineStr)
var JamesBondCar = /** @class */ (function (_super) {
    __extends(JamesBondCar, _super);
    function JamesBondCar(n, s, fly, nitro) {
        var _this = _super.call(this, n, s) || this;
        _this.canFly = fly;
        _this.useNitroPower = nitro;
        return _this;
    }
    JamesBondCar.prototype.accelerate = function () {
        return _super.prototype.accelerate.call(this) + " Can Fly ? :" + this.canFly;
    };
    return JamesBondCar;
}(Car));
var jbc = new JamesBondCar("Aston Martin", 500, true, true);
console.log(jbc.accelerate());
var Employee = /** @class */ (function () {
    function Employee() {
    }
    Employee.prototype.getDetails = function () {
        console.log(this.name, this.salary);
    };
    return Employee;
}());
// Enhanced Class
var EnhancedCar = /** @class */ (function () {
    function EnhancedCar(name, speed) {
        if (name === void 0) { name = "i20"; }
        if (speed === void 0) { speed = 200; }
        this.name = name;
        this.speed = speed;
    }
    return EnhancedCar;
}());
var enCar = new EnhancedCar();
