let esVariable = "ES6 let value !";
function Emp1(x) {
    this.salary = 50000;
    setTimeout(() => {
        console.log(this.salary);
    }, 3000);
}
