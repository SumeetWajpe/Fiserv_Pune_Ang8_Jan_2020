import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import {ProductComponent} from './product.component';
import { AppComponent } from './app.component';

@NgModule({
  declarations: [
    AppComponent,ProductComponent
  ],
  imports: [
    BrowserModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
