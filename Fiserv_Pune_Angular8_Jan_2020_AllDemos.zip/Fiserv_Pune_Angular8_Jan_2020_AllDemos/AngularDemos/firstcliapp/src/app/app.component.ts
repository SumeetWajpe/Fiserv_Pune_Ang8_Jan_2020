import { Component } from '@angular/core';
import { Product } from './product.model';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'firstcliapp';
  headerImage:string="https://upload.wikimedia.org/wikipedia/commons/thumb/c/cf/Angular_full_color_logo.svg/250px-Angular_full_color_logo.svg.png";
  products:Product[] = [
   new Product("DSLR",60000),
   new Product("Laptop",80000),
   new Product("Watch",20000),
   new Product("Mobile",30000)
    ];
}
