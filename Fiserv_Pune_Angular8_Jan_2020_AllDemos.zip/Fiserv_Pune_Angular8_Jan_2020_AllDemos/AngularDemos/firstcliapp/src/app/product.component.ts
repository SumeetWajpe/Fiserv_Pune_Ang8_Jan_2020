import {Component, Input} from '@angular/core';

@Component({
    selector:'app-product',
    template:`<h2> {{productdetails.name}} </h2>
<strong>Price : {{productdetails.price}} </strong>`
})
export class ProductComponent{
     @Input()   productdetails: any={name:"Mobile",price:20000};
}