import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http'
import { Routes, RouterModule } from '@angular/router';

import { AppComponent } from './app.component';
import { ShoppingCartComponent } from './shoppingcart.component';
import { CourseComponent } from './course.component';
import { ProductComponent } from './product/product.component';
import { ProductService } from './product/product.service';
import { PostsComponent } from './posts/posts.component';
import { PostdetailsComponent } from './postdetails/postdetails.component';
import { LoginComponent } from './login/login.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { AuthGuard } from './auth.guard';
import { DurationPipe } from './duration.pipe';
import { NewcourseComponent } from './newcourse/newcourse.component';
import { LifeCycleComponent } from './life-cycle/life-cycle.component';
import { MessageComponent } from './message/message.component';

// var routes:Routes  = [
//   {path:'',component:ShoppingCartComponent},
//   {path:'posts',component:PostsComponent},
//   {path:'postsdetails/:id',component:PostdetailsComponent},
//   {path:'products',component:ProductComponent},
//   {path:'**',redirectTo:'/'}
// ];

var routes: Routes = [
  { path: '', component: LoginComponent },
  {
    path: 'dashboard',
    component: DashboardComponent,
    //canActivate:[AuthGuard],
        children: [
      { path: '', component: ShoppingCartComponent },
      { path: 'posts', component: PostsComponent },
      { path: 'postsdetails/:id', component: PostdetailsComponent },
      { path: 'products', component: ProductComponent },
      { path: 'lifecycle', component: MessageComponent },

    ]
  }
];


@NgModule({
  declarations: [
    AppComponent, ShoppingCartComponent, CourseComponent, 
    ProductComponent, PostsComponent, PostdetailsComponent, 
    LoginComponent, DashboardComponent, DurationPipe, NewcourseComponent, LifeCycleComponent, MessageComponent
  ],
  imports: [
    BrowserModule, FormsModule, HttpClientModule, RouterModule.forRoot(routes)
  ],
  providers: [ProductService],
  bootstrap: [AppComponent]
})
export class AppModule { }
