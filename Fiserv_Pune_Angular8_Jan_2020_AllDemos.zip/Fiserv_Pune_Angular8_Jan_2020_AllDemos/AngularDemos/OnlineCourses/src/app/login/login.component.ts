import { Component, OnInit } from '@angular/core';
import { UserService } from '../user.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  txtusername:string ="";
  txtpassword:string ="";
  constructor(public userServObj:UserService,public router:Router) { }

  ngOnInit() {
  }

  Login(){
    if(this.txtusername === "admin" && this.txtpassword === "admin"){
      // set user Logged In !
      this.userServObj.setUserLoggedIn();
      // also redirect to dashboard
      this.router.navigate(['/dashboard']);
    }
  }

}
