import { Component, OnInit, Input, OnChanges } from '@angular/core';

@Component({
  selector: 'app-life-cycle',
  templateUrl: './life-cycle.component.html',
  styleUrls: ['./life-cycle.component.css']
})
export class LifeCycleComponent implements OnInit,OnChanges {
  @Input() message:string="";
  constructor() {
    console.log('(ctor) Message : ' + this.message);
   }

   // used to Initilize the component
  ngOnInit() {
    console.log('(ngOnInit) Message : ' + this.message);
  }

  ngOnChanges(){
    console.log('(ngOnChanges) Message : ' + this.message);

  }

  

}
