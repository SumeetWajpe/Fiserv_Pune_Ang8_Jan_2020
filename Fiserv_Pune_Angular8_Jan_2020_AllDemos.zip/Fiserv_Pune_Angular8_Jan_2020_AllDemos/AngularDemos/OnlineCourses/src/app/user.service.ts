import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class UserService {

  isUserLoggedIn:boolean = false;

  constructor() { }

  getUserLoggedIn(){
    // make an ajax request to authenticate !
    return this.isUserLoggedIn;
  }

  setUserLoggedIn(){
    this.isUserLoggedIn = true;
  }
}
