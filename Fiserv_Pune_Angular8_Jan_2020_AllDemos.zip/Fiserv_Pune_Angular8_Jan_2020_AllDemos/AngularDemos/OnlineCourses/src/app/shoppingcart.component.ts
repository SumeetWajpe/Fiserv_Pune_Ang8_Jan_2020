import { Component, Input } from '@angular/core';
import {CourseModel} from './course.model';
import { CourseService } from './course.service';

@Component({
    selector: 'shoppingcart',
   templateUrl:'./shoppingcart.component.html'
})
export class ShoppingCartComponent {
    heading:string="Online Courses";
    companyName:string="";
    courseName:string="";
    courses: CourseModel[] = [];
    constructor(public courseServObj: CourseService) {
            this.courses = this.courseServObj.allcourses;
    }

    ChangeHeadingHandler(){
        this.heading = "Udemy";
    }

    ChangeHeadingOnTextChange(e){
        // get the value from textbox
        // set it to heading
        this.heading = (e.target.value)
    }


}