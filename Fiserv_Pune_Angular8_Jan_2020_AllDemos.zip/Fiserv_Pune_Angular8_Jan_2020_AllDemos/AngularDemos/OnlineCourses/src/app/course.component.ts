import { Component, Input } from '@angular/core';
import { CourseModel } from './course.model';
import { CourseService } from './course.service';

@Component({
    selector: 'course',
    templateUrl: './course.component.html',
    styleUrls: ['./course.style.css']

})
export class CourseComponent {
    @Input() coursedetails: CourseModel = new CourseModel();
    isHighlighted: boolean = false;
    isFree: boolean = false;
    constructor(public courseServObj: CourseService) {
            
    }

    IncrementLikes() {
        this.coursedetails.likes++;
    }
}