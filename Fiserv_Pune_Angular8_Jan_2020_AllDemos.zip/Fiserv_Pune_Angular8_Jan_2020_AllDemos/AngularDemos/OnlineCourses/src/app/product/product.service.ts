export class ProductService{
    products:string[] = ['Mobile',"LED TV","DSLR"];

    addProduct(newProduct:string):void{
        this.products.push(newProduct);
    }
}