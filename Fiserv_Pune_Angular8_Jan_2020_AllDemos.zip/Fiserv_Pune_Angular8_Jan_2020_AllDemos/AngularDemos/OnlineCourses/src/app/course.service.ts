import { Injectable } from '@angular/core';
import { CourseModel } from './course.model';

@Injectable({
  providedIn: 'root'
})
export class CourseService {
   allcourses:CourseModel[] = [
    {name:"Typescript",quantity:10,duration:2,rating:5,price:5000,likes:400,ImageUrl:"https://proxy.duckduckgo.com/iu/?u=http%3A%2F%2Fmspoweruser.com%2Fwp-content%2Fuploads%2F2016%2F07%2Ftypescript-cover-image.jpg&f=1"},
    {name:"Angular",quantity:0,duration:3,rating:4,price:4000,likes:400,ImageUrl:"https://proxy.duckduckgo.com/iu/?u=https%3A%2F%2Fjaxenter.com%2Fwp-content%2Fuploads%2F2016%2F01%2Fshutterstock_229869889.jpg&f=1"},
    {name:"Vue",quantity:70,duration:3,rating:4.678,price:8000,likes:300,ImageUrl:"https://proxy.duckduckgo.com/iu/?u=http%3A%2F%2Fwww.programwitherik.com%2Fcontent%2Fimages%2F2017%2F01%2F87ow.png&f=1"},
    {name:"Redux",quantity:20,duration:2,rating:3,price:6000,likes:200,ImageUrl:"https://proxy.duckduckgo.com/iu/?u=http%3A%2F%2Fblog.js-republic.com%2Fwp-content%2Fuploads%2F2016%2F11%2Flogo-redux.png&f=1"},
    {name:"React",quantity:0,duration:2,rating:4,price:5000,likes:100,ImageUrl:"https://proxy.duckduckgo.com/iu/?u=http%3A%2F%2Fwww.valuecoders.com%2Fblog%2Fwp-content%2Fuploads%2F2016%2F08%2Freact.png&f=1"},
];
  constructor() { }

  AddNewCourse(courseToBeAdded:CourseModel){
    this.allcourses.push(courseToBeAdded);
  }
}
