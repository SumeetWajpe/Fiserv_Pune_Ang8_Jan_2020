import { Component, OnInit } from '@angular/core';
import { CourseModel } from '../course.model';
import { CourseService } from '../course.service';

@Component({
  selector: 'app-newcourse',
  templateUrl: './newcourse.component.html',
  styleUrls: ['./newcourse.component.css']
})
export class NewcourseComponent implements OnInit {
  newcourse:CourseModel = new CourseModel();
  constructor(public servObj:CourseService) { }

  ngOnInit() {
  }

  AddCourse(){
      this.servObj.AddNewCourse(this.newcourse);
      this.newcourse = new CourseModel();
  }

}
