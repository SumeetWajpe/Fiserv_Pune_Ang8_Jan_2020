import { Component, OnInit } from '@angular/core';
import { ProductService } from './product.service';

@Component({
  selector: 'app-product',
  templateUrl: './product.component.html',
  styleUrls: ['./product.component.css']
  //,  providers:[ProductService]  // component injection will override module level if present
})
export class ProductComponent implements OnInit {
  anewproduct:string="";
  constructor(public prodServObj:ProductService) { 
    console.log(this.prodServObj.products);  
  }
  AddNewProduct(){
        this.prodServObj.addProduct(this.anewproduct)
  }

  ngOnInit() {
  }

}
