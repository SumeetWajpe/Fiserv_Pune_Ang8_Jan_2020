import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { PostsService } from '../posts/posts.service';
import { PostsModel } from '../posts/posts.model';

@Component({
  selector: 'app-postdetails',
  templateUrl: './postdetails.component.html',
  styleUrls: ['./postdetails.component.css']
})
export class PostdetailsComponent implements OnInit {
  thePost:PostsModel = new PostsModel();
  constructor(public currRoute:ActivatedRoute,public postServObj:PostsService) {
    this.currRoute.params.subscribe(
      p => {
        this.postServObj.getAllPostById(p.id).then(
          response => {
            this.thePost = response;
            console.log(this.thePost)
          }
        )
      }
      )

    

   }

  ngOnInit() {
  }

}
