import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { PostsModel } from './posts.model';
import { Observable } from 'rxjs';

@Injectable({ providedIn: 'root' })
export class PostsService {
    constructor(public httpClientObj: HttpClient) { }
   //using observable
    // getAllPosts(): Observable<PostsModel[]> {
    //     // make an ajax request !
    //     return this.httpClientObj.get<PostsModel[]>('https://jsonplaceholder.typicode.com/posts')
    // }

    // using promise
    getAllPosts() {
        // make an ajax request !
        return this.httpClientObj.get<PostsModel[]>('https://jsonplaceholder.typicode.com/posts').toPromise()
    }

    getAllPostById(id:number) {
        // make an ajax request !
        return this.httpClientObj.get('https://jsonplaceholder.typicode.com/posts/'+id).toPromise()
    }
}