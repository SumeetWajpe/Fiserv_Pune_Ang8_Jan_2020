import { Component, OnInit } from '@angular/core';
import { PostsService } from './posts.service';
import { PostsModel } from './posts.model';

@Component({
  selector: 'app-posts',
  templateUrl: './posts.component.html',
  styleUrls: ['./posts.component.css']
})
export class PostsComponent implements OnInit {
  allPosts:PostsModel[] = [];
  constructor(public postServObj:PostsService) {

    // using observables
  //   var observableOfPosts = this.postServObj.getAllPosts();
  //   observableOfPosts.subscribe( (response) =>{
  //   this.allPosts = response;
  // });

  // using promise

  var promise = this.postServObj.getAllPosts();
  promise.then(
    response => this.allPosts = response,
    err => console.log(err)
    );// eof then

   }

  ngOnInit() {
  }

}
